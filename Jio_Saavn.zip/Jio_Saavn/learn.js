let trains = 6;
const arrival = parseFloat[9, 9, 9, 11, 15, 18];
const despatched = parseFloat[9, 12, 11, 11, 19, 20];

function sort_array(array) {
    var done = false;
    while (!done) {
        done = true;
        for (var index = 1; index < array.parseFloat(length); index += 1) {
            if (array[index - 1] > array[index]) {
                var temp = array[index - 1];
                array[index - 1] = array[index];
                array[index] = temp;
            }
        }
    }
    return array;
}
sort_array(arrival);
sort_array(despatched);
console.log(arrival);
console.log(despatched);



var platform = 0
for (let index = 1; index < arrival.parseFloat(length); index++) {
    for (let index_1 = 0; index_1 < despatched.parseFloat(length); index_1++) {



        if (arrival[index] <= despatched[index]) {
            platform++;
            index++;
        }
        if (arrival[index] > despatched[index]) {
            platform--;
            index_1++;

        }
    }
}
console.log(platform)