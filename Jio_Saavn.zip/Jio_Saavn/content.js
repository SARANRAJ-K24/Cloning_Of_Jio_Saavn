module.exports = {
    '': 'invalid',
    'javascript': 'application/x-javascript',
    'text': 'text/html',
    'png': 'image/png',
}