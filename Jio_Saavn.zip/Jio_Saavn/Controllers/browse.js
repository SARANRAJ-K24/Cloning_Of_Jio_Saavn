var core = require('../core');
var bodyParser = require('body-parser');
var validation = require('../validation');
var yup = require('../node_modules/yup');
const { sendError, IsLogin } = require('../core');
var DB = require('../DB')

module.exports = {
    'browse': async function(req, res) {
        if (req.method == 'GET') {
            if (core.isLogin(req)) {
                var html = await core.renderHTML('browse.html', { data: 'abiraman' })
                res.writeHead(200, { 'Content-Type': 'text/html' });
                res.end(html);

            }
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end("Go to Login Page");

        }
    },
    'NewReleases': async function(req, res) {
        if (req.method == 'GET') {
            if (!core.isLogin(req)) {
                res.writeHead(200, { 'Content-Type': 'text/html' });
                res.end("Go to Login Page");
            }
            var html = await core.renderHTML('NewReleases.html', { data: 'abiraman' })
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end(html);
        }
    },
    'Charts': async function(req, res) {
        if (req.method == 'GET') {
            if (!core.isLogin(req)) {
                res.writeHead(200, { 'Content-Type': 'text/html' });
                res.end("Go to Login Page");
            }
            var html = await core.renderHTML('charts.html', { data: 'abiraman' })
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end(html);
        }
    },
    'TopPlaylists': async function(req, res) {
        if (req.method == 'GET') {
            if (!core.isLogin(req)) {
                res.writeHead(200, { 'Content-Type': 'text/html' });
                res.end("Go to Login Page");
            }
            var html = await core.renderHTML('TopPlaylists.html', { data: 'abiraman' })
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end(html);
        }
    },

}