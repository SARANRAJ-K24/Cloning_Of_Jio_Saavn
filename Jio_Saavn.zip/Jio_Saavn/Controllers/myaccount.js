var core = require('../core');
var bodyParser = require('body-parser');
var validation = require('../validation');
var yup = require('../node_modules/yup');
const { sendError, IsLogin } = require('../core');
var DB = require('../DB');
const { login, signup } = require('./signup');

module.exports = {
    'myprofile': async function(req, res) {
        if (req.method == 'GET') {
            if (!core.isLogin(req)) {
                res.writeHead(200, { 'Content-Type': 'text/html' });
                res.end("Go to Login Page");
            }
            var html = await core.renderHTML('my_profile.html', { data: 'abiraman' })
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end(html);
        }
        if (req.method == 'POST') {
            var postData = await core.getUrlData(req);
            console.log(postData);
            let schema = yup.object().shape({
                email: yup.string().email().required(),
                user_name: yup.string(),
                mobile_number: yup.number(),
                date_of_birth: yup.date(),
                gender: yup.gender(),
            });
            var ValidationResult = schema.validate(postData, { abortEarly: false })
                .then(async function(valid) {
                    var sql = `INSERT INTO users VALUES (NULL,'${valid.email}')`
                    console.log(sql);
                    await DB.connection().then(function(success) {
                        success.query(sql, function(error, success) {
                            console.log(success);
                            console.log(error);
                        });
                    })
                }).catch(async function(error) {
                    console.log(error);
                    if (signup.login[0].id) {
                        var html = await core.renderHTML('my_profile.html', { error: error.errors })
                        core.sendError(res, html);
                        return error;
                    }

                    // core.sendError(res, error.errors);
                })
        }
    },
    'changepassword': async function(req, res) {
        if (req.method == 'GET') {
            if (!core.isLogin(req)) {
                res.writeHead(200, { 'Content-Type': 'text/html' });
                res.end("Go to Login Page");
            }
            var html = await core.renderHTML('changepassword.html', { data: 'abiraman' })
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end(html);
        }
        if (req.method == 'POST') {
            var postData = await core.getUrlData(req);
            console.log(postData);
            let schema = yup.object().shape({
                current_password: yup.string().required(),
                new_password: yup.string().required(),
                confirm_new_password: yup.string().required(),
            });
            var ValidationResult = schema.validate(postData, { abortEarly: false })
                .then(async function(valid) {
                    var sql = `INSERT INTO users VALUES (NULL,'${valid.email}')`
                    console.log(sql);
                    await DB.connection().then(function(success) {
                        success.query(sql, function(error, success) {
                            console.log(success);
                            console.log(error);
                        });
                    })
                }).catch(async function(error) {
                    console.log(error);
                    var html = await core.renderHTML('changepassword.html', { error: error.errors })
                    core.sendError(res, html);
                    return error;
                    // core.sendError(res, error.errors);
                })
        }
    },



}