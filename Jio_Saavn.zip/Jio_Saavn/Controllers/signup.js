var core = require('../core');
var bodyParser = require('body-parser');
var validation = require('../validation');
var yup = require('../node_modules/yup');
const { sendError, IsLogin } = require('../core');
var DB = require('../DB')


var Chumma = {
    'signup': async function(req, res) {
        if (req.method == 'GET') {
            var html = await core.renderHTML('signup.html', { data: '' })
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end(html);
        }
        if (req.method == 'POST') {
            var postData = await core.getUrlData(req);
            let schema = yup.object().shape({
                email: yup.string().email().required(),
                password: yup.string().required('Password is required'),
                passwordConfirmation: yup.string().oneOf([yup.ref('password'), null], 'Passwords must match'),
                mobile_number: yup.number().required()
            });
            var ValidationResult = schema.validate(postData, { abortEarly: false })
                .then(async function(valid) {
                    var otp = Chumma.randomNumberGenerate(100000, 999999);
                    var sql = `INSERT INTO users VALUES (NULL,'${valid.email}','${valid.password}','${valid.mobile_number}',${otp},1,'9999-12-31 22:59:59','9999-12-31 23:59:59')`
                    console.log(sql);
                    await DB.connection().then(function(success) {
                        success.query(sql, function(error, success) {
                            console.log(success);
                            console.log(error);
                        });
                    })
                }).catch(async function(error) {
                    console.log(error);
                    var html = await core.renderHTML('signup.html', { error: error.errors })
                    core.sendError(res, html);
                    return error;
                    // core.sendError(res, error.errors);
                })
        }
    },
    'randomNumberGenerate': function(min, max) {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random() * (max - min + 1)) + min;
    },
    'login': async function(req, res) {
        if (req.method == 'GET') {
            var C = core.getCookie(req);
            console.log(C);
            var html = await core.renderHTML('login.html', { data: '' })
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end(html);
        }
        if (req.method == 'POST') {
            var postData = await core.getUrlData(req);
            console.log(postData);
            let schema = yup.object().shape({
                    email: yup.string().email().required(),
                    password: yup.string().required('Password is required'),

                })
                // console.log(scheme);
            var ValidationResult = schema.validate(postData, { abortEarly: false })
                .then(async function(valid) {
                    var sql = `SELECT * FROM users WHERE email_id  = '${valid.email}' AND password = '${valid.password}' AND status = 1`
                    console.log(sql);
                    await DB.connection().then(function(success) {
                        success.query(sql, function(error, success) {
                            console.log(success);
                            if (error == null && success.length > 0) {
                                console.log(success[0].id);
                                res.writeHead(200, {
                                    'Set-Cookie': 'login=' + success[0].id
                                });
                                res.end("");
                            } else {
                                console.log("Invalid Username ,Password")
                            }
                        });
                    })

                }).catch(async function(error) {
                    console.log(error);
                    var html = await core.renderHTML('login.html', { error: error.errors })
                    core.sendError(res, html);
                    return error;
                    // core.sendError(res, error.errors);
                })
        }

    },
    'mobileLogin': async function(req, res) {
        if (req.method == 'GET') {
            var C = core.getCookie(req);
            console.log(C);
            var html = await core.renderHTML('mobileLogin.html', { data: '' })
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end(html);
        }
        if (req.method == 'POST') {
            var postData = await core.getUrlData(req);
            console.log(postData);
            let schema = yup.object().shape({
                    mobile_number: yup.number().required()
                })
                // console.log(scheme);
            var ValidationResult = schema.validate(postData, { abortEarly: false })
                .then(async function(valid) {
                    var sql = `SELECT * FROM users WHERE email_id  = '${valid.mobile_number}' AND status = 1`
                    console.log(sql);
                    await DB.connection().then(function(success) {
                        success.query(sql, function(error, success) {
                            console.log(success);
                            if (error == null && success.length > 0) {
                                console.log(success[0].id);
                                res.writeHead(200, {
                                    'Set-Cookie': 'login=' + success[0].id
                                });
                                res.end("");
                            } else {
                                console.log("Invalid Username ,Password")
                            }
                        });
                    })

                }).catch(async function(error) {
                    console.log(error);
                    var html = await core.renderHTML('login.html', { error: error.errors })
                    core.sendError(res, html);
                    return error;
                    // core.sendError(res, error.errors);
                })
        }

    },
    'termsAndServices': async function(req, res) {
        if (req.method == 'GET') {
            if (!core.isLogin(req)) {
                res.writeHead(200, { 'Content-Type': 'text/html' });
                res.end("Go to Login Page");
            }
            var html = await core.renderHTML('termsAndServices.html', { data: '' })
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end(html);
        }
    },
    'forgotpassword': async function(req, res) {
        if (req.method == 'GET') {
            var html = await core.renderHTML('forgotpassword.html', { data: '' })
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end(html);
        }
        if (req.method == 'POST') {
            var postData = await core.getUrlData(req);
            console.log(postData);
            let schema = yup.object().shape({
                email: yup.string().email().required(),
            });
            var ValidationResult = schema.validate(postData, { abortEarly: false })
                .then(async function(valid) {
                    var sql = `INSERT INTO users VALUES (NULL,'${valid.email}')`
                    console.log(sql);
                    await DB.connection().then(function(success) {
                        success.query(sql, function(error, success) {
                            console.log(success);
                            console.log(error);
                        });
                    })
                }).catch(async function(error) {
                    console.log(error);
                    var html = await core.renderHTML('forgotpassword.html', { error: error.errors })
                    core.sendError(res, html);
                    return error;
                    // core.sendError(res, error.errors);
                })
        }
    },
    'home': async function(req, res) {
        if (req.method == 'GET') {
            if (!core.isLogin(req)) {
                res.writeHead(200, { 'Content-Type': 'text/html' });
                res.end("Go to Login Page");
            }
            var html = await core.renderHTML('home.html', { data: 'Email' })
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end(html);
        }

    },

}
module.exports = Chumma;