var core = require('../core');
var bodyParser = require('body-parser');
var validation = require('../validation');
var yup = require('../node_modules/yup');
const { sendError, IsLogin, getCookie } = require('../core');
var DB = require('../DB')

module.exports = {
    'home': async function(req, res) {
        if (req.method == 'GET') {
            if (!core.isLogin(req)) {
                res.writeHead(200, { 'Content-Type': 'text/html' });
                res.end("Go to Login Page");
            }
            var html = await core.renderHTML('home.html', { data: '' })
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end(html);
        }
    },
    'history': async function(req, res) {
        if (req.method == 'GET') {
            if (!core.isLogin(req)) {
                res.writeHead(200, { 'Content-Type': 'text/html' });
                res.end("Go to Login Page");
            }
            var html = await core.renderHTML('history.html', { data: '' })
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end(html);
        }
        var ValidationResult = schema.validate(postData, { abortEarly: false })
            .then(async function(valid) {
                var sql = `SELECT * FROM users WHERE email_id  = '${valid.email}' AND password = '${valid.password}' AND status = 1`
                console.log(sql);
                await DB.connection().then(function(success) {
                    success.query(sql, function(error, success) {
                        console.log(success);
                        if (error == null && success.length > 0) {
                            console.log(success[0].id);
                            res.writeHead(200, {
                                'Set-Cookie': 'login=' + success[0].id
                            });
                            res.end("");
                        } else {
                            console.log("Invalid Username ,Password")
                        }
                    });
                })

            }).catch(async function(error) {
                console.log(error);
                var html = await core.renderHTML('login.html', { error: error.errors })
                core.sendError(res, html);
                return error;
                // core.sendError(res, error.errors);
            })
    },
    'songs': async function(req, res) {
        if (req.method == 'GET') {
            if (!core.isLogin(req)) {
                res.writeHead(200, {
                    'Content-Type': 'text/html',
                    'Content-Type': 'application/json',
                    'Content-Type': 'image/jpeg'
                });
                res.end("Go to Login Page");
            }
            var html = await core.renderHTML('songs.html', { data: '' })
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end(html);
        }
    },
    'albums': async function(req, res) {
        if (req.method == 'GET') {
            if (!core.isLogin(req)) {
                res.writeHead(200, { 'Content-Type': 'text/html' });
                res.end("Go to Login Page");
            }
            var html = await core.renderHTML('albums.html', { data: '' })
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end(html);
        }
    },
}